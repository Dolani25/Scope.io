TOKEN = 'your_telegram_bot_token'
ALLOWED_USERS = ['user_id_1', 'user_id_2']  # List of allowed user IDs as strings
PASTEBIN_API_KEY = 'your_pastebin_api_key'